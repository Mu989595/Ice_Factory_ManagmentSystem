using IceFactoryManagmentSystem.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IceFactoryManagmentSystem.Infrastructure.Persistence.Configurations;

public class WorkerConfiguration : IEntityTypeConfiguration<Worker>
{
    public void Configure(EntityTypeBuilder<Worker> builder)
    {
        builder.ToTable("workers");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
               .ValueGeneratedOnAdd();

        builder.Property(x => x.FullName)
               .IsRequired()
               .HasMaxLength(100);

        // Stored as string in DB, mapped to enum in app
        builder.Property(x => x.Role)
               .IsRequired()
               .HasMaxLength(30)
               .HasConversion<string>();

        builder.Property(x => x.DailyWage)
               .IsRequired()
               .HasColumnType("decimal(10,2)");

        builder.Property(x => x.IsActive)
               .IsRequired()
               .HasDefaultValue(true);

        builder.Property(x => x.HiredAt)
               .IsRequired()
               .HasColumnType("date");

        // Navigation
        builder.HasMany(x => x.DailyAttendances)
               .WithOne(a => a.Worker)
               .HasForeignKey(a => a.WorkerId)
               .OnDelete(DeleteBehavior.Restrict);
    }
}
