using IceFactoryManagmentSystem.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace IceFactoryManagmentSystem.Infrastructure.Persistence.Configurations;

public class DailyAttendanceConfiguration : IEntityTypeConfiguration<DailyAttendance>
{
    public void Configure(EntityTypeBuilder<DailyAttendance> builder)
    {
        builder.ToTable("daily_attendance");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
               .ValueGeneratedOnAdd();

        builder.Property(x => x.LedgerDayId)
               .IsRequired();

        builder.Property(x => x.WorkerId)
               .IsRequired();

        // One attendance record per worker per day
        builder.HasIndex(x => new { x.LedgerDayId, x.WorkerId })
               .IsUnique();

        builder.Property(x => x.Attended)
               .IsRequired()
               .HasDefaultValue(true);

        builder.Property(x => x.WagePaid)
               .IsRequired()
               .HasColumnType("decimal(10,2)");

        builder.Property(x => x.Notes)
               .HasMaxLength(200);
    }
}
